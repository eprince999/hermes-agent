XL330 可转动驱动盘 假电机

打印这两件:
  xl330_body_spin.stl   壳体 20x34x26 mm，已掏轴孔
  xl330_horn_spin.stl   驱动盘 + 4mm 轴，从输出端插入即可转动

对照:
  xl330_horn_official.stl  官方驱动盘（无轴）
  XL330_XC330.stp          ROBOTIS 官方 STEP

单位: 毫米
轴 4.0mm / 孔 4.6mm。太松把盘打 101%，太紧打磨轴。
来源: https://www.robotis.com/service/download.php?no=1987
